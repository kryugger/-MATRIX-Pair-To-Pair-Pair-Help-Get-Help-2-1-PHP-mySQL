<?php
Include('include-global.php');
$pagename = "About Us";
$title = "$pagename - $basetitle";
Include('include-header.php');
?>

</head>
<body class="stretched" data-loader="<?php echo $baseloader; ?>" data-loader-color='<?php echo "#$basecolor"; ?>'>

<!-- 
<body class="stretched" data-loader-html="<div id='css3-spinner-svg-pulse-wrapper'><svg id='css3-spinner-svg-pulse' version='1.2' height='210' width='550' xmlns='http://www.w3.org/2000/svg' viewport='0 0 60 60' xmlns:xlink='http://www.w3.org/1999/xlink'><path id='css3-spinner-pulse' stroke='#DE6262' fill='none' stroke-width='2' stroke-linejoin='round' d='M0,90L250,90Q257,60 262,87T267,95 270,88 273,92t6,35 7,-60T290,127 297,107s2,-11 10,-10 1,1 8,-10T319,95c6,4 8,-6 10,-17s2,10 9,11h210' /></svg></div>">

 -->

<?php
Include('include-navbar.php');
Include('include-subhead.php');
?>
<section id="content">
<div class="content-wrap">
<div class="container clearfix">








<p style="text-align: justify;">
	
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi veritatis cupiditate impedit maiores quidem perspiciatis, omnis, reiciendis odio rem quisquam eum laudantium optio beatae amet aspernatur. Fugiat quibusdam saepe libero iure dolores harum, blanditiis laboriosam eligendi provident ad rem reprehenderit debitis, exercitationem, nihil quasi laudantium soluta aspernatur ipsa. Optio similique repudiandae saepe alias iure repellat perspiciatis unde deleniti suscipit nostrum laudantium porro rem neque, magni doloremque, sint distinctio fugit quas quam rerum ipsum eum modi aut. Suscipit nemo, doloremque quae! Nam beatae itaque, nesciunt ab magni ratione nihil ut? Impedit provident, maxime cum enim pariatur iste, dolorem, nesciunt dolor adipisci ipsa quas molestiae fuga molestias nostrum, fugiat natus est unde esse. At asperiores, obcaecati fugit minus voluptatem est sunt cupiditate, iste iusto eveniet rem corrupti a illum voluptate fuga. Repellat consequatur doloremque, ipsum, explicabo consequuntur sint perspiciatis laborum pariatur nihil dolor excepturi officiis quis dignissimos quidem nesciunt. Magnam nesciunt dolores, aliquam doloremque libero molestiae in harum quidem voluptatibus porro et illum. Voluptatum aliquid unde eaque cupiditate, esse cumque iste, totam odit ipsa dignissimos quis ea doloribus facere possimus voluptatibus. Quia ipsa voluptate delectus cupiditate similique animi, ex recusandae placeat! A, commodi maxime! Tenetur ducimus a dolores. Corporis eum officia commodi, aspernatur, aperiam unde necessitatibus error praesentium sit, placeat iure. Atque vel voluptatibus beatae minima adipisci ipsum enim error rem doloribus commodi explicabo, eos omnis consectetur aliquid dolorum culpa vitae animi dolor esse odit, praesentium saepe sunt quis fugiat! Amet unde vel non quia suscipit, reprehenderit error consequuntur, iure, voluptates asperiores sapiente dolores voluptatibus illo culpa dolore aliquam. Commodi nulla veritatis, distinctio quis, reiciendis, incidunt laboriosam eos tenetur omnis fugiat sint! Amet optio aliquam, tempora, dolores magnam debitis vitae pariatur saepe iure nisi unde sapiente quisquam veniam animi assumenda itaque fugiat impedit odio adipisci eius similique cum minus distinctio perspiciatis! Recusandae nobis rem beatae itaque deleniti repellendus ipsam eum blanditiis, aspernatur culpa accusamus animi dolor officiis, enim illo nulla sunt quod ipsa unde tempore possimus accusantium distinctio. Animi rerum nesciunt quibusdam neque aut. Explicabo velit, voluptates maiores ad commodi quae architecto consequuntur fugit. Illo corporis velit ducimus, soluta quia excepturi dicta fugit id. Facilis odio numquam est a neque, ea modi ducimus laudantium quos accusantium sit atque ipsam sint autem quidem magnam sapiente dignissimos quas iste debitis nesciunt. Esse quas qui repudiandae quaerat voluptate sed porro labore ut, provident dignissimos quo, maxime id eos numquam nemo optio accusamus ab sit explicabo facilis minus totam possimus accusantium sequi eaque. Adipisci facilis veniam similique sed accusantium optio, cumque praesentium dolorem at rerum neque ratione nulla nihil temporibus eveniet reiciendis, mollitia harum debitis aut. Eaque maiores quasi cumque ex velit et voluptatem laboriosam quis, obcaecati ea tempore, inventore provident veniam dignissimos impedit ullam nihil sit. Earum error commodi eligendi, tempora adipisci nemo, at laborum repellat ipsam voluptatem molestiae. Sed placeat aperiam nulla praesentium obcaecati modi voluptatem illum dolorem! Quis nemo asperiores nesciunt reprehenderit cupiditate deserunt quasi, eius voluptatum facere ab. Minima tenetur perferendis in eos odit soluta totam atque quia, assumenda itaque aperiam? Repudiandae.


</p>









</div>
</div>
</section>
<?php
Include('include-footer.php');
?>

</body>
</html>