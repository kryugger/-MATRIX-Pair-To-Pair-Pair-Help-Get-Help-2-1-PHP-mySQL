<?php
include ('include/header.php');
if($usid[2]!=100){
redirect('home.php');
}
?>
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo">
<?php
include ('include/sidebar.php');
?>

            
 

		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                   
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Edit Menu
<a href="listmenu.php" class="btn btn-lg btn-primary pull-right"><i class="fa fa-desktop"></i> View All Menu </a>
                    </h3>
                    <!-- END PAGE TITLE-->

					<hr>

					
					
					
					
					
			<div class="row">
			<div class="col-md-12">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                
                                <div class="portlet-body form">
                                    <form class="form-horizontal" action="" method="post" role="form">
                                        <div class="form-body">

		   
<?php

if (isset($_GET['id'])) {
$iidd = $_GET["id"];
}else{
$iidd =1;
}
if ($iidd>3 || $iidd<1) {
$iidd =1;
}


$count = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM fmenu WHERE id='".$iidd."'"));
if($count[0]==0){
    mysql_query("INSERT INTO fmenu SET id='".$iidd."'");
}


if($_POST)
{

$name = mysql_real_escape_string($_POST["name"]);
$btext = mysql_real_escape_string($_POST["btext"]);


$err1=0;
$err2=0;




if(trim($name)=="")
      {
$err1=1;
}




$error = $err1+$err2;


if ($error == 0){
	
$res = mysql_query("UPDATE fmenu SET name='".$name."', btext='".$btext."' WHERE id='".$iidd."'");
echo mysql_error();
if($res){
notification("Updated Successfully!", "", "success", false, "btn-primary", "OKAY");
}else{
notification("Some Problem Occurs!", "Please Try Again...", "error", false, "btn-primary", "OKAY");
}

} else {
	
if ($err1 == 1){
echo "<div class=\"alert alert-danger alert-dismissable\">
<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>	
Name Can Not be Empty!!!
</div>";
}		
}
}

$old = mysql_fetch_array(mysql_query("SELECT name, btext FROM fmenu WHERE id='".$iidd."'"));
?>										
										
										

<div class="row">
    
<div class="col-md-4">
    <a href="?id=1" class="btn purple btn-block btn-lg">Privacy Policy</a>
</div>
    
<div class="col-md-4">
    <a href="?id=2" class="btn purple btn-block btn-lg">Terms of Use</a>
</div>
    
<div class="col-md-4">
    <a href="?id=3" class="btn purple btn-block btn-lg">Warning</a>
</div>

<br><br><br><br><br><br>

</div>


						
						
						
	<div class="form-group">
    <label class="col-md-12"><strong>Menu Name</strong></label>
    <div class="col-md-12">
     <input class="form-control input-lg" name="name" value="<?php echo $old[0]; ?>" type="text">
    </div>
    </div>

     
     
    <div class="form-group">
    <label class="col-md-12"><strong>Menu Bar Name</strong></label>
    <div class="col-md-12">
    <textarea id="shaons" class="form-control" rows="20" name="btext"><?php echo $old[1]; ?></textarea>
    </div>
    </div>


<div class="row">
    <div class="col-md-12">
        <button type="submit" class="btn blue btn-lg btn-block">Update</button>
    </div>
</div>
											
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>		
                        </div><!---ROW-->		
					
					
					
					
					
					
		
					
					
					
					
					
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            
			


<?php
 include ('include/footer.php');
 ?>
</body>
</html>