<?php
include ('include/header.php');
if($usid[2]!=100){
redirect('home.php');
}
?>
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo">
<?php
include ('include/sidebar.php');
?>


		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                   
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Dashboard
                        <small>Statistics</small>
                    </h3>
                    <!-- END PAGE TITLE-->

					<hr>




                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                
            <div class="row">



<div class="col-md-3">

<strong style="font-size: 28px;">1</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/ae247b0b0e70697e6fc12e488942d2245e2df9a5/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f312e676966" alt="Loader 1">

</div><div class="col-md-3">
<strong style="font-size: 28px;">2</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/1985f89c6cc1e387766b0f35903069eeb78848a6/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f322e676966" alt="Loader 2">

</div><div class="col-md-3">
<strong style="font-size: 28px;">3</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/7e91f5c329dfc6b4ef216597584424101d17ba51/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f332e676966" alt="Loader 3">

</div><div class="col-md-3">
<strong style="font-size: 28px;">4</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/285f609ef02ffd23f7efd846ad5df990c6afd6b6/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f342e676966" alt="Loader 4">

</div><div class="col-md-3">
<strong style="font-size: 28px;">5</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/2390883b2706a5380add27be00ab3af3be4e4e65/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f352e676966" alt="Loader 5">

</div><div class="col-md-3">
<strong style="font-size: 28px;">6</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/927990e0119c31cfd7000d0e4461d0b503d91ec2/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f362e676966" alt="Loader 6">

</div><div class="col-md-3">
<strong style="font-size: 28px;">7</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/e86498511d8f94e923d2242d5042865a8bfbe609/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f372e676966" alt="Loader 7">

</div><div class="col-md-3">
<strong style="font-size: 28px;">8</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/2bdb140014007e90c18b69fb4046bcdca105f0ed/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f382e676966" alt="Loader 8">

</div><div class="col-md-3">
<strong style="font-size: 28px;">9</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/82f1243a68a988c6c952e6c1e565b97618c5a670/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f392e676966" alt="Loader 9">

</div><div class="col-md-3">
<strong style="font-size: 28px;">10</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/191510d3e4b1b7f585056d6163acb28618421c2b/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f31312e676966" alt="Loader 10">

</div><div class="col-md-3">
<strong style="font-size: 28px;">11</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/586e56b9587d30dab746e0695d4600cb4eee0184/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f31302e676966" alt="Loader 11">

</div><div class="col-md-3">
<strong style="font-size: 28px;">12</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/37a2c75ae0a11cd512eca2638ae655ecb03be311/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f31322e676966" alt="Loader 12">

</div><div class="col-md-3">
<strong style="font-size: 28px;">13</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/9bfe630b108b1c857f90ce41e0f200b3f8d42d02/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f31332e676966" alt="Loader 13">

</div><div class="col-md-3">
<strong style="font-size: 28px;">14</strong> 
<img src="https://d1a6a9r46cnyll.cloudfront.net/7bd689e7ab94d8e93270b4122455c73c3ab67c4f/687474703a2f2f7468656d65732e73656d69636f6c6f6e7765622e636f6d2f696d616765732f68746d6c2f63616e7661732f6c6f616465722f31342e676966" alt="Loader 14">




            </div>
            </div>
            </div>





<?php

if(isset($_POST['lid'])) {
$lid = $_POST["lid"];

$res = mysql_query("UPDATE general_setting SET lid='".$lid."' WHERE id='1'");
if($res){
notification("UPDATED Successfully!", "", "success", false, "btn-primary", "OKAY");
}else{
notification("Some Problem Occurs!", "Please Try Again...", "error", false, "btn-primary", "OKAY");
}

}


$old = mysql_fetch_array(mysql_query("SELECT lid FROM general_setting WHERE id='1'"));

?>



<form action="" method="post">
<div class="row">
<div class="col-md-6"> <input type="text" name="lid" class="form-control input-lg" placeholder="LOADER ID" value="<?php echo $old[0]; ?>"></div>
<div class="col-md-6"> <button type="submit" class="btn btn-lg btn-block btn-primary"> UPDATE</button></div>
</div>
</form>











                    
</div>
<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->


<?php
 include ('include/footer.php');
 ?>

<!-- BEGIN PAGE LEVEL PLUGINS -->


<script src="assets/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>

<script src="assets/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>



</body>
</html>