<?php
$baseurl = "http://abir.khan/ddv2"; ////// Member Panel URL
$adminurl = "http://abir.khan/ddv2/newadmin"; ////// Admin Panel URL
$purchaseCode = ""; ////// Envato purchase Code
date_default_timezone_set('Asia/Dhaka');
$tm = time();
error_reporting(E_ALL);
$dbname = "ddv2";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
?>