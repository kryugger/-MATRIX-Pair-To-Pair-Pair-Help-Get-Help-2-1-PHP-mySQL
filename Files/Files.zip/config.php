<?php

$baseurl = "http://abir.khan/dd-cc-up"; ////// Member Panel URL
$adminurl = "http://abir.khan/dd-cc-up/admin"; ////// Admin Panel URL
$purchaseCode = ""; ////// Envato purchase Code
date_default_timezone_set("Asia/Dhaka");
$tm = time();
error_reporting(E_ALL);

$dbname = "dd-cc-up";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
?>
