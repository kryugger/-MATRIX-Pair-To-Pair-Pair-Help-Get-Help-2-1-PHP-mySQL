<!-- <section id="page-title" class="page-title-mini">

<div class="container clearfix">
<h1 style="color: #<?php echo $basecolor; ?>;"><?php echo $pagename; ?></h1>

</div>

</section> -->